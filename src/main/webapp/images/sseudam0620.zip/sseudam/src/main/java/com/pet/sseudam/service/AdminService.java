package com.pet.sseudam.service;

import com.pet.sseudam.model.AdminBean;

public interface AdminService {
    AdminBean adminCheck(String a_email);
}
