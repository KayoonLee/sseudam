package com.pet.sseudam.dao;

public interface BoardDao {

}
